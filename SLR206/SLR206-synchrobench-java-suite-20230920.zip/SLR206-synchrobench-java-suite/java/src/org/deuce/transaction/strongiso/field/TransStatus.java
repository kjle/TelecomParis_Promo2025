package org.deuce.transaction.strongiso.field;

public class TransStatus {

	public static final int LIVE = 0, ABORTED = 1, COMMITTED = 2;

}
