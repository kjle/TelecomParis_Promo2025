package org.deuce.transform;

public class UseStrongIso {
	
	public static final boolean USE_STRONG_ISO = false;
	public static String owner;
	public static String name;
	public static String desc;
}
