/* This file should contain the configuration parameters
   necessary for the Mex-compilation. */

#ifndef CONFIG_H
#define CONFIG_H 1

#define FFTW_OPTITYPE FFTW_ESTIMATE

#endif /* CONFIG_H */
